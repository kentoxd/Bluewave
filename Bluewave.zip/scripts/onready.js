document.addEventListener('DOMContentLoaded', (event) => {
    const header = document.querySelector('.header');
    header.style.height = window.innerHeight + 'px';   
});